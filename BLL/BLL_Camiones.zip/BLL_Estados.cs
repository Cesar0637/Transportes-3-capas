﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using DAL;
using System.Collections.Generic;
using VO;

namespace BLL
{
    public class BLL_Estados
    {
        // CRUD
        public static string insertar_Estado(Estados_VO estado)
        {
            return DAL_Estados.insertar_Estado(estado);
        }

        public static List<Estados_VO> get_Estados(params object[] parametros)
        {
            return DAL_Estados.get_Estados(parametros);
        }

        public static string update_Estado(Estados_VO estado)
        {
            return DAL_Estados.update_Estado(estado);
        }

        public static string eliminar_Estado(int id)
        {
            return DAL_Estados.eliminar_Estado(id);
        }
    }
}